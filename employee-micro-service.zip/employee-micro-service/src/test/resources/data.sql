INSERT INTO 
	EMPLOYEES (id, first_name, last_name, email, phone) 
VALUES
  	('Julian', 'Pankiraj', 'julian@brighttalk.com'),
  	('John', 'Ray', 'john.ray@brighttalk.com');